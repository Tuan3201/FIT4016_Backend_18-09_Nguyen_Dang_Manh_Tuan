from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json
import os
from datetime import datetime

# Cài đặt: pip install google-generativeai
try:
    import google.generativeai as genai
    AI_AVAILABLE = True
except ImportError:
    AI_AVAILABLE = False
    print("⚠️  google-generativeai chưa cài. Chạy: pip install google-generativeai")

# Lấy API key từ environment variable
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')

if AI_AVAILABLE and GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel('gemini-pro')
else:
    model = None

class AIHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        if self.path == '/health':
            response = {
                'status': 'running',
                'ai_available': AI_AVAILABLE and model is not None,
                'timestamp': datetime.now().isoformat()
            }
        else:
            response = {'error': 'Not found'}
        
        self.wfile.write(json.dumps(response).encode())
    
    def do_POST(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length).decode('utf-8')
            data = json.loads(body)
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            if self.path == '/ask':
                question = data.get('question', '')
                use_ai = data.get('use_ai', True)
                context = data.get('context', '')
                
                if not question:
                    response = {'error': 'Question is required'}
                elif use_ai and model:
                    response = self.ask_ai(question, context)
                else:
                    response = {'error': 'AI not available', 'use_faq': True}
                
                self.wfile.write(json.dumps(response).encode())
            else:
                response = {'error': 'Endpoint not found'}
                self.wfile.write(json.dumps(response).encode())
        
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {'error': str(e)}
            self.wfile.write(json.dumps(response).encode())
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-type')
        self.end_headers()
    
    def ask_ai(self, question, context=''):
        try:
            # Tạo prompt chuyên môn cho CNTT
            system_prompt = """Bạn là một trợ lý học tập chuyên ngành CNTT (Công Nghệ Thông Tin).
Hãy trả lời câu hỏi về:
- Lập trình (C, Python, Java, JavaScript, ...)
- Cấu trúc dữ liệu & Giải thuật
- Database & SQL
- Web & Internet
- OOP & Design Patterns
- Network & Security
- Cloud & DevOps
- AI & Machine Learning

Yêu cầu:
1. Trả lời bằng TIẾNG VIỆT
2. Giải thích chi tiết nhưng dễ hiểu
3. Nêu ví dụ cụ thể nếu cần
4. Trích dẫn mã code khi phù hợp
5. Tổng hợp ngắn gọn (200-500 từ)

Context thêm: """ + context
            
            prompt = system_prompt + "\n\nCâu hỏi: " + question
            
            response = model.generate_content(
                prompt,
                generation_config=genai.types.GenerationConfig(
                    max_output_tokens=1024,
                    temperature=0.7,
                )
            )
            
            answer = response.text
            
            return {
                'success': True,
                'answer': answer,
                'source': 'Gemini AI',
                'model': 'gemini-pro'
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'use_faq': True
            }
    
    def log_message(self, format, *args):
        # Ẩn thông báo GET request
        if 'GET' in format:
            return
        super().log_message(format, *args)

def run_ai_server(port=5001):
    server_address = ('', port)
    httpd = HTTPServer(server_address, AIHandler)
    print(f"🤖 AI Server chạy tại http://localhost:{port}")
    print(f"📌 AI Status: {'✅ Gemini AI sẵn sàng' if (AI_AVAILABLE and model) else '⚠️  Cần cấu hình API key'}")
    print(f"💡 Để bật Gemini: set GEMINI_API_KEY=your_key_here")
    print("Nhấn Ctrl+C để dừng...\n")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 AI Server đã dừng")
        httpd.server_close()

if __name__ == '__main__':
    run_ai_server()
