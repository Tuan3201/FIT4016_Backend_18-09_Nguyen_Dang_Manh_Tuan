# Architecture Diagram - Chatbot Tư Vấn Học Tập

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                            USER INTERFACES                              │
├─────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐ │
│  │   Web App    │  │  Mobile App  │  │  Zalo/Telegram│  │  Admin Panel│ │
│  │   (React)    │  │  (React Native)│  │  Integration  │  │ (Dashboard) │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └─────────────┘ │
└──────────────────────────┬─────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         API GATEWAY / Load Balancer                      │
├─────────────────────────────────────────────────────────────────────────┤
│                         (Nginx / AWS ALB)                                │
└──────────────────────────┬─────────────────────────────────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ▼                  ▼                  ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  Backend 1   │  │  Backend 2   │  │  Backend N   │
│ (Node.js)    │  │ (Node.js)    │  │ (Node.js)    │
├──────────────┤  ├──────────────┤  ├──────────────┤
│ • Auth API   │  │ • Auth API   │  │ • Auth API   │
│ • Chat API   │  │ • Chat API   │  │ • Chat API   │
│ • FAQ API    │  │ • FAQ API    │  │ • FAQ API    │
│ • Admin API  │  │ • Admin API  │  │ • Admin API  │
└──────┬───────┘  └──────┬───────┘  └──────┬───────┘
       │                 │                 │
       └─────────────────┼─────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
    ┌────────┐   ┌────────────┐   ┌────────────┐
    │  JWT   │   │   NLP      │   │  Cache    │
    │ Token  │   │  Engine    │   │  (Redis)  │
    └────────┘   │ • Classifier   └────────────┘
                 │ • Intent      
                 │ • Entity      
                 │ • Response
                 │ Generator
                 └────────────┘
                 │
        ┌────────┴────────┐
        │                 │
        ▼                 ▼
┌──────────────────────────────────────────┐
│         CORE SERVICES LAYER              │
├──────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────────┐ │
│  │  Auth        │  │  Chatbot Service │ │
│  │  Service     │  │  • Message       │ │
│  │ • Register   │  │    Processing    │ │
│  │ • Login      │  │  • Intent        │ │
│  │ • JWT        │  │    Detection     │ │
│  │ • Roles      │  │  • Response      │ │
│  │              │  │    Generation    │ │
│  └──────────────┘  └──────────────────┘ │
│  ┌──────────────┐  ┌──────────────────┐ │
│  │  FAQ Service │  │  Analytics       │ │
│  │ • Search     │  │  Service         │ │
│  │ • Filter     │  │ • Track Usage    │ │
│  │ • Update     │  │ • Analyze Intent │ │
│  │ • Maintain   │  │ • Generate       │ │
│  │              │  │   Reports        │ │
│  └──────────────┘  └──────────────────┘ │
└────────────┬─────────────────────────────┘
             │
    ┌────────┴───────┬──────────────┐
    │                │              │
    ▼                ▼              ▼
┌─────────────┐ ┌────────────┐ ┌──────────────┐
│  MongoDB    │ │  Redis     │ │  Search     │
│  Database   │ │  Cache     │ │  Elasticsearch
├─────────────┤ └────────────┘ └──────────────┘
│ • Users     │
│ • Conversations
│ • FAQ       │
│ • Feedback  │
│ • Schedules │
└─────────────┘

       │
       ▼
┌──────────────────────────────────┐
│     STORAGE & BACKUP LAYER       │
├──────────────────────────────────┤
│ • Replication                    │
│ • Backup                         │
│ • Disaster Recovery              │
└──────────────────────────────────┘
```

## Data Flow Diagram

```
User Input
    │
    ▼
┌───────────────────┐
│ Validate Input    │
│ (Client Side)     │
└────────┬──────────┘
         │
         ▼
┌───────────────────┐
│ Send to Backend   │
│ (POST Request)    │
└────────┬──────────┘
         │
         ▼
┌───────────────────────┐
│ Authentication Check  │
│ (Verify JWT Token)    │
└────────┬──────────────┘
         │
    ┌────┴────┐
    │          │
    ▼          ▼
┌────────┐ ┌────────────┐
│ Invalid│ │   Valid    │
│ Return │ │   Continue │
│ Error  │ └──────┬─────┘
└────────┘        │
                  ▼
            ┌───────────────────┐
            │ Process Message   │
            │ 1. Preprocess     │
            │ 2. Tokenize       │
            │ 3. Detect Intent  │
            └────────┬──────────┘
                     │
                     ▼
            ┌───────────────────┐
            │ Search FAQ DB     │
            │ (Intent Matching) │
            └────────┬──────────┘
                     │
                 ┌───┴───┐
                 │       │
             Found   Not Found
                 │       │
                 ▼       ▼
            ┌────────┐ ┌──────────────┐
            │ Use    │ │ Generate     │
            │ FAQ    │ │ Default      │
            │ Answer │ │ Response     │
            └────┬───┘ └────────┬─────┘
                 │             │
                 └──────┬──────┘
                        │
                        ▼
                ┌──────────────────┐
                │ Save Conversation│
                │ (To MongoDB)     │
                └────────┬─────────┘
                         │
                         ▼
                ┌──────────────────┐
                │ Return Response  │
                │ to Client        │
                └────────┬─────────┘
                         │
                         ▼
                    Display Reply
                    to User
```

## Service Dependencies

```
┌─────────────────────────────────────────────┐
│          Frontend Services                   │
├─────────────────────────────────────────────┤
│ • Authentication Module                     │
│ • Chat Interface                            │
│ • FAQ Search                                │
│ • Admin Dashboard                           │
│ • User Profile                              │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│       Backend API Endpoints                  │
├─────────────────────────────────────────────┤
│ • /api/auth/* (Authentication)              │
│ • /api/chatbot/* (Chat Operations)          │
│ • /api/faq/* (FAQ Management)               │
│ • /api/admin/* (Administration)             │
│ • /api/users/* (User Management)            │
└──────────────────┬──────────────────────────┘
                   │
            ┌──────┴──────┐
            │             │
            ▼             ▼
    ┌────────────┐   ┌─────────────┐
    │ Middleware │   │ Controllers │
    │ • Auth     │   │ • Process   │
    │ • Validate │   │ • Respond   │
    │ • Error    │   │ • Transform │
    └────────────┘   └─────────────┘
            │             │
            └──────┬──────┘
                   │
                   ▼
        ┌──────────────────────┐
        │ Business Logic Layer │
        ├──────────────────────┤
        │ • NLP Engine         │
        │ • Chat Service       │
        │ • FAQ Service        │
        │ • User Service       │
        │ • Analytics Service  │
        └──────────┬───────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │ Data Access Layer    │
        ├──────────────────────┤
        │ • User Repository    │
        │ • Conversation DAO   │
        │ • FAQ Repository     │
        │ • Feedback Model     │
        └──────────┬───────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │ Database Layer       │
        ├──────────────────────┤
        │ • MongoDB            │
        │ • Redis Cache        │
        └──────────────────────┘
```

## Scalability Strategy

```
Increasing Load
    │
    ▼
┌────────────────────┐
│ Single Instance    │ ◄─ Load 0-1000 req/min
│ (Development)      │
└────────────────────┘
    │
    ▼ Increasing Load
┌────────────────────┐
│ Horizontal Scaling │ ◄─ Load 1000-10k req/min
│ Multiple Backend   │
│ Instances          │
├────────────────────┤
│ + Load Balancer    │
│ + Shared Database  │
└────────────────────┘
    │
    ▼ Increasing Load
┌────────────────────┐
│ Advanced Scaling   │ ◄─ Load >10k req/min
│ + Caching Layer    │
│ + CDN              │
│ + Database Replica │
│ + Message Queue    │
├────────────────────┤
│ + Microservices    │
│ + Kubernetes       │
└────────────────────┘
```

## Technology Stack

```
Frontend Layer          Backend Layer        Data Layer
├─ React 18             ├─ Node.js 18        ├─ MongoDB 5+
├─ React Router         ├─ Express.js        ├─ Redis
├─ Zustand              ├─ JWT               └─ ElasticSearch
├─ Tailwind CSS         ├─ bcryptjs
├─ Axios                ├─ Mongoose
└─ React Icons          ├─ natural (NLP)
                        └─ Multer

Deployment             Monitoring            DevOps
├─ Docker              ├─ PM2                ├─ Git
├─ Docker Compose      ├─ Winston Logger     ├─ CI/CD
├─ Nginx               ├─ New Relic          ├─ GitHub Actions
└─ Kubernetes          └─ Sentry             └─ Terraform
```
