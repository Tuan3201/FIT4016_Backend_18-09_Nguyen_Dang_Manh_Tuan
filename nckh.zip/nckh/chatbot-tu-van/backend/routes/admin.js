const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

// Apply admin middleware to all routes
router.use(authenticateToken, authorizeRole('admin'));

router.get('/dashboard', adminController.getDashboardStats);
router.get('/users', adminController.getUsers);
router.put('/users/:userId', adminController.updateUser);
router.delete('/users/:userId', adminController.deleteUser);
router.get('/analytics/conversations', adminController.getConversationAnalytics);
router.get('/analytics/feedback', adminController.getFeedbackAnalytics);

module.exports = router;
