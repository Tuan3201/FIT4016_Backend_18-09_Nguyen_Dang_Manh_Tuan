const express = require('express');
const router = express.Router();
const faqController = require('../controllers/faqController');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

// Public routes
router.get('/', faqController.getAllFAQs);
router.get('/search', faqController.searchFAQs);
router.post('/:faqId/view', faqController.trackFAQView);
router.post('/:faqId/helpful', faqController.markFAQHelpful);

// Admin routes
router.post('/', authenticateToken, authorizeRole('admin'), faqController.createFAQ);
router.put('/:faqId', authenticateToken, authorizeRole('admin'), faqController.updateFAQ);
router.delete('/:faqId', authenticateToken, authorizeRole('admin'), faqController.deleteFAQ);

module.exports = router;
