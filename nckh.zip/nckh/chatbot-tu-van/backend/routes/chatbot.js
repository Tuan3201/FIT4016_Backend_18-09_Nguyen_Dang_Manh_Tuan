const express = require('express');
const router = express.Router();
const chatbotController = require('../controllers/chatbotController');
const { authenticateToken } = require('../middleware/auth');

router.post('/send-message', authenticateToken, chatbotController.sendMessage);
router.get('/conversations', authenticateToken, chatbotController.getConversations);
router.get('/conversations/:conversationId', authenticateToken, chatbotController.getConversationDetail);
router.delete('/conversations/:conversationId', authenticateToken, chatbotController.deleteConversation);
router.post('/conversations/:conversationId/rate', authenticateToken, chatbotController.rateResponse);

module.exports = router;
