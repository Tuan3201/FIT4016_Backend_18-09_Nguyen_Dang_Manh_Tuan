const mongoose = require('mongoose');

const scheduleSchema = new mongoose.Schema({
  semester: {
    type: String,
    required: true
  },
  academicYear: {
    type: String,
    required: true
  },
  courses: [{
    courseId: String,
    name: String,
    instructor: String,
    schedule: String,
    room: String,
    credits: Number,
    startDate: Date,
    endDate: Date
  }],
  examDates: [{
    courseId: String,
    courseName: String,
    date: Date,
    time: String,
    room: String
  }],
  holidays: [{
    name: String,
    startDate: Date,
    endDate: Date
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Schedule', scheduleSchema);
