const natural = require('natural');
const tokenizer = new natural.WordTokenizer();
const stemmer = natural.PorterStemmer;

const intents = {
  schedule: {
    patterns: ['lịch học', 'lịch', 'buổi học', 'lớp học', 'thời khóa biểu', 'khi nào có lớp', 'học lúc nào'],
    responses: [
      'Bạn muốn xem lịch học lớp nào?',
      'Hãy cho tôi biết lớp hoặc môn bạn muốn xem lịch',
      'Bạn cần xem lịch học của kì nào?'
    ]
  },
  exam: {
    patterns: ['thi', 'lịch thi', 'kỳ thi', 'ngày thi', 'giờ thi', 'khi nào thi', 'thi cái gì'],
    responses: [
      'Bạn muốn biết lịch thi của kì nào?',
      'Tôi có thể giúp bạn xem lịch thi',
      'Hãy chọn kì học bạn muốn xem lịch thi'
    ]
  },
  score: {
    patterns: ['điểm', 'điểm số', 'bảng điểm', 'điểm thi', 'điểm quá trình', 'xem điểm', 'điểm của tôi'],
    responses: [
      'Bạn muốn xem điểm của môn nào?',
      'Hãy cho tôi biết tên môn bạn muốn xem điểm',
      'Tôi có thể giúp bạn tra cứu điểm'
    ]
  },
  procedure: {
    patterns: ['thủ tục', 'xin nghỉ', 'đăng ký', 'tờ khai', 'hồ sơ', 'giấy tờ', 'làm sao', 'làm thế nào'],
    responses: [
      'Bạn cần hỗ trợ với thủ tục nào?',
      'Tôi có thể hướng dẫn bạn',
      'Vui lòng nêu rõ thủ tục bạn cần'
    ]
  },
  study_method: {
    patterns: ['học', 'phương pháp', 'tài liệu', 'tài liệu học', 'gợi ý học', 'làm sao để học tốt', 'kỹ năng'],
    responses: [
      'Bạn muốn tìm tài liệu về môn nào?',
      'Tôi có thể gợi ý một số tài liệu và phương pháp học',
      'Bạn cần giúp đỡ về vấn đề gì?'
    ]
  },
  greeting: {
    patterns: ['xin chào', 'chào', 'hi', 'hello', 'mồn', 'buổi sáng', 'buổi chiều', 'buổi tối'],
    responses: [
      'Xin chào! Tôi là chatbot tư vấn học tập của Khoa CNTT. Tôi có thể giúp bạn với lịch học, lịch thi, điểm số, hoặc các thủ tục hành chính. Bạn cần gì?',
      'Chào bạn! 👋 Mình ở đây để giúp bạn. Bạn cần tư vấn về cái gì?',
      'Xin chào bạn! 😊 Tôi sẵn sàng hỗ trợ bạn'
    ]
  }
};

class NLPEngine {
  constructor() {
    this.intents = intents;
  }

  preprocessText(text) {
    return text
      .toLowerCase()
      .trim()
      .replace(/[!?.,;:]/g, '');
  }

  calculateSimilarity(str1, str2) {
    const s1 = this.preprocessText(str1);
    const s2 = this.preprocessText(str2);
    
    const longer = s1.length > s2.length ? s1 : s2;
    const shorter = s1.length > s2.length ? s2 : s1;
    
    if (longer.length === 0) return 1.0;
    
    const editDistance = this.getEditDistance(longer, shorter);
    return (longer.length - editDistance) / longer.length;
  }

  getEditDistance(s1, s2) {
    const costs = [];
    for (let i = 0; i <= s1.length; i++) {
      let lastValue = i;
      for (let j = 0; j <= s2.length; j++) {
        if (i === 0) {
          costs[j] = j;
        } else if (j > 0) {
          let newValue = costs[j - 1];
          if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
            newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
          }
          costs[j - 1] = lastValue;
          lastValue = newValue;
        }
      }
      if (i > 0) costs[s2.length] = lastValue;
    }
    return costs[s2.length];
  }

  detectIntent(userMessage) {
    const cleanMessage = this.preprocessText(userMessage);
    let bestMatch = { intent: 'other', confidence: 0 };

    for (const [intentName, intentData] of Object.entries(this.intents)) {
      for (const pattern of intentData.patterns) {
        const similarity = this.calculateSimilarity(cleanMessage, pattern);
        
        if (similarity > bestMatch.confidence) {
          bestMatch = {
            intent: intentName,
            confidence: similarity,
            pattern: pattern
          };
        }
      }
    }

    return bestMatch;
  }

  getRandomResponse(intentName) {
    const intentData = this.intents[intentName];
    if (!intentData) {
      return 'Tôi xin lỗi, tôi chưa hiểu rõ câu hỏi của bạn. Bạn có thể phát biểu lại được không?';
    }
    
    const responses = intentData.responses;
    return responses[Math.floor(Math.random() * responses.length)];
  }

  async processMessage(userMessage) {
    const intentResult = this.detectIntent(userMessage);
    const response = this.getRandomResponse(intentResult.intent);

    return {
      userMessage,
      response,
      intent: intentResult.intent,
      confidence: parseFloat(intentResult.confidence.toFixed(2))
    };
  }
}

module.exports = new NLPEngine();
