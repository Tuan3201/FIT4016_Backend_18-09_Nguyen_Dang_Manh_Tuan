const Conversation = require('../models/Conversation');
const FAQ = require('../models/FAQ');
const nlpEngine = require('../nlp/nlpEngine');

exports.sendMessage = async (req, res) => {
  try {
    const { message, conversationId } = req.body;
    const userId = req.user.id;

    if (!message || !message.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Tin nhắn không được để trống'
      });
    }

    // Process message with NLP
    const nlpResult = await nlpEngine.processMessage(message);

    // Find FAQ with similar intent
    let faqResponse = null;
    if (nlpResult.intent !== 'greeting') {
      const faqs = await FAQ.find({
        category: nlpResult.intent,
        isActive: true
      });

      if (faqs.length > 0) {
        faqResponse = faqs[0].answer;
      }
    }

    const botResponse = faqResponse || nlpResult.response;

    // Save conversation
    let conversation;
    if (conversationId) {
      conversation = await Conversation.findByIdAndUpdate(
        conversationId,
        {
          $push: {
            messages: [
              {
                role: 'user',
                content: message,
                timestamp: new Date()
              },
              {
                role: 'bot',
                content: botResponse,
                intent: nlpResult.intent,
                confidence: nlpResult.confidence,
                timestamp: new Date()
              }
            ]
          },
          updatedAt: new Date()
        },
        { new: true }
      );
    } else {
      conversation = new Conversation({
        userId,
        title: message.substring(0, 50),
        category: nlpResult.intent,
        messages: [
          {
            role: 'user',
            content: message
          },
          {
            role: 'bot',
            content: botResponse,
            intent: nlpResult.intent,
            confidence: nlpResult.confidence
          }
        ]
      });
      await conversation.save();
    }

    res.json({
      success: true,
      conversationId: conversation._id,
      botResponse,
      intent: nlpResult.intent,
      confidence: nlpResult.confidence
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi xử lý tin nhắn',
      error: error.message
    });
  }
};

exports.getConversations = async (req, res) => {
  try {
    const userId = req.user.id;
    const conversations = await Conversation.find({ userId })
      .sort({ createdAt: -1 })
      .limit(20);

    res.json({
      success: true,
      conversations
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi lấy cuộc hội thoại',
      error: error.message
    });
  }
};

exports.getConversationDetail = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const userId = req.user.id;

    const conversation = await Conversation.findOne({
      _id: conversationId,
      userId
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Cuộc hội thoại không tìm thấy'
      });
    }

    res.json({
      success: true,
      conversation
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi lấy chi tiết cuộc hội thoại',
      error: error.message
    });
  }
};

exports.deleteConversation = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const userId = req.user.id;

    const conversation = await Conversation.findOneAndDelete({
      _id: conversationId,
      userId
    });

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Cuộc hội thoại không tìm thấy'
      });
    }

    res.json({
      success: true,
      message: 'Xóa cuộc hội thoại thành công'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi xóa cuộc hội thoại',
      error: error.message
    });
  }
};

exports.rateResponse = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const { rating, comment, isHelpful } = req.body;
    const userId = req.user.id;

    const conversation = await Conversation.findOneAndUpdate(
      {
        _id: conversationId,
        userId
      },
      {
        feedback: {
          rating,
          comment,
          helpful: isHelpful
        }
      },
      { new: true }
    );

    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: 'Cuộc hội thoại không tìm thấy'
      });
    }

    res.json({
      success: true,
      message: 'Đánh giá thành công'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi đánh giá',
      error: error.message
    });
  }
};
