const FAQ = require('../models/FAQ');

exports.createFAQ = async (req, res) => {
  try {
    const { question, answer, category, tags, keywords, examples, intent } = req.body;

    const faq = new FAQ({
      question,
      answer,
      category,
      tags: tags || [],
      keywords: keywords || [],
      examples: examples || [],
      intent,
      createdBy: req.user.id
    });

    await faq.save();

    res.status(201).json({
      success: true,
      message: 'Tạo FAQ thành công',
      faq
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi tạo FAQ',
      error: error.message
    });
  }
};

exports.getAllFAQs = async (req, res) => {
  try {
    const { category } = req.query;
    const query = { isActive: true };

    if (category) {
      query.category = category;
    }

    const faqs = await FAQ.find(query)
      .sort({ priority: -1, viewCount: -1 });

    res.json({
      success: true,
      faqs
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi lấy FAQ',
      error: error.message
    });
  }
};

exports.searchFAQs = async (req, res) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        message: 'Vui lòng nhập từ khóa tìm kiếm'
      });
    }

    const faqs = await FAQ.find({
      $or: [
        { question: { $regex: q, $options: 'i' } },
        { answer: { $regex: q, $options: 'i' } },
        { keywords: { $regex: q, $options: 'i' } },
        { tags: { $regex: q, $options: 'i' } }
      ],
      isActive: true
    });

    res.json({
      success: true,
      faqs
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi tìm kiếm FAQ',
      error: error.message
    });
  }
};

exports.updateFAQ = async (req, res) => {
  try {
    const { faqId } = req.params;
    const { question, answer, category, tags, keywords, examples, priority } = req.body;

    const faq = await FAQ.findByIdAndUpdate(
      faqId,
      {
        question,
        answer,
        category,
        tags,
        keywords,
        examples,
        priority,
        updatedBy: req.user.id,
        updatedAt: new Date()
      },
      { new: true }
    );

    if (!faq) {
      return res.status(404).json({
        success: false,
        message: 'FAQ không tìm thấy'
      });
    }

    res.json({
      success: true,
      message: 'Cập nhật FAQ thành công',
      faq
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi cập nhật FAQ',
      error: error.message
    });
  }
};

exports.deleteFAQ = async (req, res) => {
  try {
    const { faqId } = req.params;

    const faq = await FAQ.findByIdAndUpdate(
      faqId,
      { isActive: false },
      { new: true }
    );

    if (!faq) {
      return res.status(404).json({
        success: false,
        message: 'FAQ không tìm thấy'
      });
    }

    res.json({
      success: true,
      message: 'Xóa FAQ thành công'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi xóa FAQ',
      error: error.message
    });
  }
};

exports.trackFAQView = async (req, res) => {
  try {
    const { faqId } = req.params;

    await FAQ.findByIdAndUpdate(
      faqId,
      { $inc: { viewCount: 1 } }
    );

    res.json({
      success: true,
      message: 'Đã ghi lại lượt xem'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi ghi lại lượt xem',
      error: error.message
    });
  }
};

exports.markFAQHelpful = async (req, res) => {
  try {
    const { faqId } = req.params;
    const { helpful } = req.body;

    const updateData = helpful 
      ? { $inc: { helpfulCount: 1 } }
      : { $inc: { unhelpfulCount: 1 } };

    await FAQ.findByIdAndUpdate(faqId, updateData);

    res.json({
      success: true,
      message: 'Cảm ơn phản hồi của bạn'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi ghi lại phản hồi',
      error: error.message
    });
  }
};
