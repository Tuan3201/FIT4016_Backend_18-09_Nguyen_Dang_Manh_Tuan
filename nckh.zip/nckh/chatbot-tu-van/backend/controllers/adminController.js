const User = require('../models/User');
const Conversation = require('../models/Conversation');
const FAQ = require('../models/FAQ');
const Feedback = require('../models/Feedback');

exports.getDashboardStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalConversations = await Conversation.countDocuments();
    const totalFAQs = await FAQ.countDocuments({ isActive: true });
    
    const avgRating = await Feedback.aggregate([
      { $group: { _id: null, avgRating: { $avg: '$rating' } } }
    ]);

    res.json({
      success: true,
      stats: {
        totalUsers,
        totalConversations,
        totalFAQs,
        avgRating: avgRating[0]?.avgRating || 0
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi lấy thống kê',
      error: error.message
    });
  }
};

exports.getUsers = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    const users = await User.find()
      .select('-password')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    const total = await User.countDocuments();

    res.json({
      success: true,
      users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi lấy danh sách người dùng',
      error: error.message
    });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const { name, email, role, isActive } = req.body;

    const user = await User.findByIdAndUpdate(
      userId,
      { name, email, role, isActive, updatedAt: new Date() },
      { new: true }
    ).select('-password');

    res.json({
      success: true,
      message: 'Cập nhật người dùng thành công',
      user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi cập nhật người dùng',
      error: error.message
    });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { userId } = req.params;

    await User.findByIdAndDelete(userId);
    await Conversation.deleteMany({ userId });

    res.json({
      success: true,
      message: 'Xóa người dùng thành công'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi xóa người dùng',
      error: error.message
    });
  }
};

exports.getConversationAnalytics = async (req, res) => {
  try {
    const totalConversations = await Conversation.countDocuments();
    
    const byCategory = await Conversation.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } }
    ]);

    const avgMessagesPerConversation = await Conversation.aggregate([
      { $project: { messageCount: { $size: '$messages' } } },
      { $group: { _id: null, avg: { $avg: '$messageCount' } } }
    ]);

    res.json({
      success: true,
      analytics: {
        totalConversations,
        byCategory,
        avgMessagesPerConversation: avgMessagesPerConversation[0]?.avg || 0
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi lấy phân tích cuộc hội thoại',
      error: error.message
    });
  }
};

exports.getFeedbackAnalytics = async (req, res) => {
  try {
    const totalFeedback = await Feedback.countDocuments();
    
    const ratingDistribution = await Feedback.aggregate([
      { $group: { _id: '$rating', count: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]);

    const avgRating = await Feedback.aggregate([
      { $group: { _id: null, avgRating: { $avg: '$rating' } } }
    ]);

    const helpfulCount = await Feedback.countDocuments({ isHelpful: true });

    res.json({
      success: true,
      analytics: {
        totalFeedback,
        ratingDistribution,
        avgRating: avgRating[0]?.avgRating || 0,
        helpfulCount,
        unhelpfulCount: totalFeedback - helpfulCount
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Lỗi lấy phân tích phản hồi',
      error: error.message
    });
  }
};
