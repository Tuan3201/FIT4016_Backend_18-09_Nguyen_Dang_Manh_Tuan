# ⚡ HƯỚNG DẪN NHANH - KÍCH HOẠT AI TRONG 2 PHÚT

## 🎯 Vấn Đề: Toggle AI không hoạt động?

Nguyên nhân: **Chưa có API Key** hoặc **AI Server chưa chạy**

---

## ✅ GIẢI PHÁP (Chọn 1 trong 2)

### **CÁCH 1: Sử dụng Script Tự Động (Dễ nhất) ⭐**

1. **Mở PowerShell** tại thư mục: `d:\baocaotiendo\nckh\chatbot-tu-van\`

2. **Chạy script:**
   ```powershell
   .\run-ai-server.ps1
   ```

3. **Script sẽ hỏi bạn API Key**
   - Nếu không có → nhập "Not now" hoặc Enter
   - Nếu có → Dán API key rồi Enter

---

### **CÁCH 2: Chạy Manual (Chi tiết)**

#### Bước 1️⃣: Lấy API Key Miễn Phí
- Truy cập: **https://aistudio.google.com/app/apikey**
- Click **"Create API Key"** → **"Create API key in new project"**
- Copy API key (dạng: `AIzaSyDxRt7...`)

#### Bước 2️⃣: Khởi Động Server (PowerShell)
```powershell
# Cách A: Tạm thời (chỉ lần này)
$env:GEMINI_API_KEY = 'AIzaSyDxRt7...'
python ai_server.py

# Cách B: Lưu vĩnh viễn (cho tất cả lần sau)
[Environment]::SetEnvironmentVariable('GEMINI_API_KEY','AIzaSyDxRt7...','User')
# Sau đó khởi động lại PowerShell và chạy: python ai_server.py
```

---

## 🔍 KIỂM TRA AI SERVER CHẠY ĐÚNG KHÔNG

Khi chạy `python ai_server.py`, bạn sẽ thấy:

### ✅ **Nếu Thành Công:**
```
🤖 AI Server chạy tại http://localhost:5001
📌 AI Status: ✅ Gemini AI sẵn sàng
...
```

### ❌ **Nếu Lỗi - Kiểm Tra:**
```
⚠️  google-generativeai chưa cài
→ Chạy: pip install google-generativeai

⚠️  Cần cấu hình API key
→ Set env var GEMINI_API_KEY trước
```

---

## 🎮 SAU KHI AI SERVER CHẠY

1. **Truy cập Chatbot**: http://localhost:3000/ai-enabled.html
2. **Đăng nhập/Đăng ký**
3. **Click toggle** trên navbar (thay đổi 📚 FAQ → 🤖 AI)
   - Nếu không click được → Xem mục "Troubleshooting"
   - Nếu click được → AI đã hoạt động ✅

---

## 🆘 TROUBLESHOOTING

### **Q: Toggle vẫn không bật?**
**A:** 
- Kiểm tra AI Server có message "✅ Gemini AI sẵn sàng" không?
- Nếu không → Chạy script `run-ai-server.ps1` hoặc cách 2
- Nếu có → F5 (reload) trình duyệt

### **Q: AI Server báo "google-generativeai chưa cài"?**
**A:** Chạy: `pip install google-generativeai`

### **Q: "Invalid API key"?**
**A:** 
- Lấy API key mới từ: https://aistudio.google.com/app/apikey
- Chắc chắn copy đúng (không có khoảng trắng)
- Set lại env var: `$env:GEMINI_API_KEY = 'key-mới'`

### **Q: "Server không phản hồi"?**
**A:**
- Port 5001 bị chiếm? → Tìm process: `netstat -ano | findstr :5001`
- Firewall chặn? → Cho phép Python qua Firewall
- Restart: Tắt Terminal AI Server, chạy lại

### **Q: Tôi chỉ muốn dùng FAQ (không cần AI)?**
**A:** 
- Đơn giản! Chatbot sẽ tự dùng FAQ nếu AI không sẵn
- Toggle vẫn có thể bật (nhưng khi hỏi sẽ dùng FAQ)
- Hoặc để OFF toggle là được

---

## 💾 LƯỚI TRỢ GIÚP NHANH

| Vấn Đề | Giải Pháp |
|--------|----------|
| Toggle không mở | Chạy `run-ai-server.ps1` |
| API key lỗi | Lấy mới từ aistudio.google.com |
| Python lỗi | `pip install google-generativeai` |
| Quên API key | Không sao, dùng FAQ mode |

---

## 🚀 NHỮNG ĐIỀU CẢN NHỚ

✅ **FAQ luôn hoạt động** - 80+ câu, offline  
✅ **AI thêm được** - Vô hạn kiến thức, cần API key  
✅ **Fallback tự động** - Nếu AI hỏng, tự dùng FAQ  
✅ **Hai server** - Frontend (3000) + AI (5001)  

---

**👉 Bây giờ chạy: `.\run-ai-server.ps1` để bắt đầu!**
