#!/bin/bash

echo "=== Chatbot Tư Vấn Học Tập - Setup Script ==="

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}Node.js chưa được cài đặt${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Node.js đã được cài đặt${NC}"

# Check if MongoDB is installed
if ! command -v mongod &> /dev/null; then
    echo -e "${YELLOW}⚠ MongoDB chưa được cài đặt. Bạn cần cài đặt nó trước.${NC}"
    echo "  Tải về tại: https://www.mongodb.com/try/download/community"
fi

# Setup Backend
echo -e "\n${YELLOW}>>> Setting up Backend...${NC}"
cd backend

if [ ! -f ".env" ]; then
    echo "Tạo file .env..."
    cp .env.example .env
    echo -e "${GREEN}✓ File .env đã được tạo${NC}"
    echo "  Vui lòng chỉnh sửa .env với thông tin MongoDB của bạn"
else
    echo -e "${GREEN}✓ File .env đã tồn tại${NC}"
fi

echo "Cài đặt npm packages..."
npm install

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Backend setup hoàn thành${NC}"
else
    echo -e "${RED}✗ Backend setup thất bại${NC}"
    exit 1
fi

# Setup Frontend
echo -e "\n${YELLOW}>>> Setting up Frontend...${NC}"
cd ../frontend

if [ ! -f ".env" ]; then
    echo "Tạo file .env..."
    cp .env.example .env
    echo -e "${GREEN}✓ File .env đã được tạo${NC}"
else
    echo -e "${GREEN}✓ File .env đã tồn tại${NC}"
fi

echo "Cài đặt npm packages..."
npm install

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Frontend setup hoàn thành${NC}"
else
    echo -e "${RED}✗ Frontend setup thất bại${NC}"
    exit 1
fi

echo -e "\n${GREEN}=== Setup hoàn thành! ===${NC}"
echo ""
echo "Các bước tiếp theo:"
echo "1. Đảm bảo MongoDB đang chạy"
echo "2. Chạy backend: cd backend && npm run dev"
echo "3. Chạy frontend: cd frontend && npm start"
echo ""
