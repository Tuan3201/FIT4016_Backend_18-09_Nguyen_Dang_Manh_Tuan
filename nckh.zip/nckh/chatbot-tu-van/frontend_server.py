#!/usr/bin/env python3
"""
Simple HTTP Server for serving the Frontend
Run: python frontend_server.py
"""

from http.server import HTTPServer, SimpleHTTPRequestHandler
from datetime import datetime
import os

class FrontendHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        """Handle GET requests"""
        if self.path == '/' or self.path == '':
            self.path = '/index.html'
        
        return SimpleHTTPRequestHandler.do_GET(self)
    
    def end_headers(self):
        """Add CORS headers"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        SimpleHTTPRequestHandler.end_headers(self)
    
    def log_message(self, format, *args):
        """Custom logging"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {format % args}")

if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    server_address = ('', 3000)
    httpd = HTTPServer(server_address, FrontendHandler)
    
    print("🌐 Frontend Server đang chạy tại http://localhost:3000")
    print("📂 Phục vụ files từ: " + os.getcwd())
    print("🛑 Nhấn Ctrl+C để dừng server\n")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n✅ Frontend Server đã dừng")
        httpd.server_close()
