# Hướng dẫn triển khai

## Triển khai cục bộ (Local)

### Bước 1: Chuẩn bị môi trường

Cài đặt các công cụ cần thiết:
- Node.js (v14+)
- MongoDB (v4+)
- Git

### Bước 2: Clone và setup

```bash
# Clone dự án
git clone <repository-url>
cd chatbot-tu-van

# Chạy script setup (Windows)
setup.bat

# Hoặc (Linux/Mac)
bash setup.sh
```

### Bước 3: Khởi động MongoDB

```bash
# Windows
"C:\Program Files\MongoDB\Server\4.4\bin\mongod.exe"

# macOS (với Homebrew)
brew services start mongodb-community

# Linux
sudo systemctl start mongod
```

### Bước 4: Khởi động Backend

```bash
cd backend
npm run dev  # Development mode
```

Server sẽ chạy ở `http://localhost:5000`

### Bước 5: Khởi động Frontend

```bash
cd frontend
npm start
```

App sẽ mở tại `http://localhost:3000`

## Triển khai với Docker

### Bước 1: Cài Docker

Tải và cài Docker Desktop từ https://www.docker.com/products/docker-desktop

### Bước 2: Build và chạy

```bash
# Chạy tất cả dịch vụ
docker-compose up -d

# Xem logs
docker-compose logs -f

# Dừng dịch vụ
docker-compose down
```

Truy cập:
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- MongoDB: localhost:27017

## Triển khai lên Cloud

### Azure App Service

```bash
# Tạo resource group
az group create --name chatbot-rg --location eastasia

# Tạo App Service Plan
az appservice plan create --name chatbot-plan --resource-group chatbot-rg --sku B1 --is-linux

# Deploy backend
az webapp create --resource-group chatbot-rg --plan chatbot-plan --name chatbot-backend --deployment-source-url <git-repo> --runtime "NODE|18"

# Deploy frontend
az webapp create --resource-group chatbot-rg --plan chatbot-plan --name chatbot-frontend --deployment-source-url <git-repo> --runtime "NODE|18"

# Tạo Azure Cosmos DB (MongoDB API)
az cosmosdb create --name chatbot-cosmos --resource-group chatbot-rg --kind MongoDB
```

### Heroku

```bash
# Cài Heroku CLI
npm install -g heroku

# Login
heroku login

# Tạo app
heroku create chatbot-backend
heroku create chatbot-frontend

# Add MongoDB add-on
heroku addons:create mongolab --app chatbot-backend

# Deploy
git push heroku main
```

### AWS (EC2)

```bash
# Connect to EC2
ssh -i your-key.pem ec2-user@your-ip

# Install Node.js
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install nodejs

# Install MongoDB
sudo yum install mongodb-org
sudo systemctl start mongod

# Clone và setup
git clone <repo>
cd chatbot-tu-van
npm install

# Run with PM2
npm install -g pm2
pm2 start npm --name chatbot-backend -- run start
pm2 startup
pm2 save
```

## Kiểm tra triển khai

### Health Check

```bash
# Kiểm tra backend
curl http://localhost:5000/api/health

# Kết quả mong đợi:
# {"status":"OK","timestamp":"2024-01-22T00:00:00.000Z"}
```

### Test API

```bash
# Đăng ký
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "password123"
  }'

# Đăng nhập
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
```

## Cấu hình Production

### Backend

Tạo file `backend/.env.production`:

```
PORT=5000
MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/chatbot-tu-van
JWT_SECRET=your_very_secure_random_string_here
NODE_ENV=production
API_URL=https://api.example.com
FRONTEND_URL=https://example.com
```

### Frontend

Tạo file `frontend/.env.production`:

```
REACT_APP_API_URL=https://api.example.com
```

## Backup & Restore

### MongoDB Backup

```bash
# Backup
mongodump --uri="mongodb://localhost:27017/chatbot-tu-van" --out=./backup

# Restore
mongorestore --uri="mongodb://localhost:27017/chatbot-tu-van" ./backup/chatbot-tu-van
```

## Monitoring & Logging

### PM2 Monitoring

```bash
# Install PM2
npm install -g pm2

# Start with PM2
pm2 start backend/server.js --name chatbot-backend

# Monitoring
pm2 monit

# View logs
pm2 logs chatbot-backend

# Save
pm2 save
pm2 startup
```

## Troubleshooting

### MongoDB không kết nối

```bash
# Kiểm tra MongoDB đang chạy
mongo --eval "db.adminCommand('ping')"

# Khởi động MongoDB
sudo systemctl start mongod  # Linux
brew services start mongodb-community  # macOS
```

### API không trả lời

```bash
# Kiểm tra port
netstat -an | grep 5000

# Kill process nếu cần
lsof -i :5000
kill -9 <PID>
```

### Frontend không kết nối Backend

```bash
# Kiểm tra CORS settings ở backend
# Đảm bảo FRONTEND_URL đúng trong .env

# Xóa browser cache
# Restart frontend dev server
```

## SSL/TLS Certificate (Cho HTTPS)

```bash
# Với Let's Encrypt
sudo apt-get install certbot

# Tạo certificate
sudo certbot certonly --standalone -d example.com

# Tự động renew
sudo certbot renew --dry-run
```

## Performance Optimization

1. **Caching**: Thêm Redis cache cho FAQ
2. **CDN**: Sử dụng CloudFlare hoặc AWS CloudFront
3. **Database Indexing**: Tối ưu MongoDB indexes
4. **Compression**: Gzip response
5. **Load Balancing**: Sử dụng Nginx hoặc HAProxy

## Security Checklist

- [ ] Change default JWT secret
- [ ] Use HTTPS in production
- [ ] Enable CORS properly
- [ ] Validate input data
- [ ] Use environment variables cho sensitive data
- [ ] Regular backups
- [ ] Monitor logs for suspicious activity
- [ ] Keep dependencies updated
