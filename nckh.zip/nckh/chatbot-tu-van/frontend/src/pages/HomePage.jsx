import React, { useState, useEffect } from 'react';
import ChatWindow from '../components/ChatWindow';
import { useAuthStore } from '../store/store';
import { api } from '../api';
import { FiPlus, FiTrash2 } from 'react-icons/fi';

export default function HomePage() {
  const { user, token } = useAuthStore();
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      loadConversations();
    }
  }, [token]);

  const loadConversations = async () => {
    try {
      const result = await api.getConversations(token);
      if (result.success) {
        setConversations(result.conversations);
      }
    } catch (error) {
      console.error('Lỗi tải cuộc hội thoại:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConversation = async (conversationId) => {
    try {
      const result = await api.deleteConversation(conversationId, token);
      if (result.success) {
        setConversations(conversations.filter(c => c._id !== conversationId));
        if (selectedConversation?._id === conversationId) {
          setSelectedConversation(null);
        }
      }
    } catch (error) {
      console.error('Lỗi xóa cuộc hội thoại:', error);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4">Vui lòng đăng nhập</h2>
          <p className="text-gray-600">Để sử dụng chatbot, bạn cần đăng nhập trước</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg overflow-y-auto">
        <div className="p-4">
          <button
            onClick={() => setSelectedConversation(null)}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 mb-4"
          >
            <FiPlus size={20} />
            Cuộc hội thoại mới
          </button>

          <h3 className="text-gray-700 font-semibold mb-4 text-sm">Lịch sử</h3>
          {conversations.map((conv) => (
            <div
              key={conv._id}
              onClick={() => setSelectedConversation(conv)}
              className={`p-3 rounded-lg mb-2 cursor-pointer flex justify-between items-center group ${
                selectedConversation?._id === conv._id
                  ? 'bg-blue-100 border border-blue-400'
                  : 'hover:bg-gray-100 border border-gray-200'
              }`}
            >
              <span className="text-sm truncate flex-1">{conv.title}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteConversation(conv._id);
                }}
                className="opacity-0 group-hover:opacity-100 transition"
              >
                <FiTrash2 size={16} className="text-red-500" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 p-4">
        <ChatWindow conversationId={selectedConversation?._id} />
      </div>
    </div>
  );
}
