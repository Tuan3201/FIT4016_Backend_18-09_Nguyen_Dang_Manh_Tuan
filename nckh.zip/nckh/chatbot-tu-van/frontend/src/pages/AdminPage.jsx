import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../store/store';
import { api } from '../api';
import { FiBarChart2, FiUsers, FiMessageSquare, FiStar } from 'react-icons/fi';

export default function AdminPage() {
  const { user, token } = useAuthStore();
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token && user?.role === 'admin') {
      loadData();
    }
  }, [token, user]);

  const loadData = async () => {
    try {
      const [statsRes, usersRes, analyticsRes] = await Promise.all([
        api.getDashboardStats(token),
        api.getUsers(1, 20, token),
        api.getConversationAnalytics(token)
      ]);

      if (statsRes.success) setStats(statsRes.stats);
      if (usersRes.success) setUsers(usersRes.users);
      if (analyticsRes.success) setAnalytics(analyticsRes.analytics);
    } catch (error) {
      console.error('Lỗi tải dữ liệu:', error);
    } finally {
      setLoading(false);
    }
  };

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <h2 className="text-2xl text-red-600">Bạn không có quyền truy cập</h2>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-4xl font-bold mb-8">Dashboard Admin</h1>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Tổng người dùng</p>
                <p className="text-3xl font-bold">{stats.totalUsers}</p>
              </div>
              <FiUsers size={32} className="text-blue-500" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Cuộc hội thoại</p>
                <p className="text-3xl font-bold">{stats.totalConversations}</p>
              </div>
              <FiMessageSquare size={32} className="text-green-500" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">FAQ</p>
                <p className="text-3xl font-bold">{stats.totalFAQs}</p>
              </div>
              <FiBarChart2 size={32} className="text-yellow-500" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Đánh giá trung bình</p>
                <p className="text-3xl font-bold">{stats.avgRating.toFixed(1)}</p>
              </div>
              <FiStar size={32} className="text-orange-500" />
            </div>
          </div>
        </div>
      )}

      {/* Users Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-6 border-b">
          <h2 className="text-xl font-bold">Người dùng gần đây</h2>
        </div>
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold">Tên</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Email</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Vai trò</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Trạng thái</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id} className="border-b hover:bg-gray-50">
                <td className="px-6 py-3">{u.name}</td>
                <td className="px-6 py-3">{u.email}</td>
                <td className="px-6 py-3">
                  <span className={`px-3 py-1 rounded text-sm font-medium ${
                    u.role === 'admin' ? 'bg-red-100 text-red-800' :
                    u.role === 'teacher' ? 'bg-blue-100 text-blue-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {u.role === 'admin' ? 'Quản trị' : u.role === 'teacher' ? 'Giảng viên' : 'Sinh viên'}
                  </span>
                </td>
                <td className="px-6 py-3">
                  <span className={`px-3 py-1 rounded text-sm ${
                    u.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {u.isActive ? 'Hoạt động' : 'Không hoạt động'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
