import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/store';
import { FiMenu, FiLogOut, FiHome, FiMessageSquare, FiUser } from 'react-icons/fi';

export default function Navbar() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <div 
          onClick={() => navigate('/')}
          className="text-2xl font-bold cursor-pointer flex items-center gap-2"
        >
          <FiMessageSquare size={28} />
          Chatbot Tư Vấn
        </div>

        <div className="flex items-center gap-6">
          {user ? (
            <>
              <div className="flex items-center gap-2">
                <FiUser size={20} />
                <span>{user.name}</span>
              </div>
              {user.role === 'admin' && (
                <button
                  onClick={() => navigate('/admin')}
                  className="px-3 py-2 bg-white text-blue-600 rounded hover:bg-gray-100"
                >
                  Admin
                </button>
              )}
              <button
                onClick={handleLogout}
                className="px-3 py-2 bg-red-500 rounded hover:bg-red-600 flex items-center gap-2"
              >
                <FiLogOut size={18} />
                Đăng xuất
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => navigate('/login')}
                className="px-3 py-2 bg-white text-blue-600 rounded hover:bg-gray-100"
              >
                Đăng nhập
              </button>
              <button
                onClick={() => navigate('/register')}
                className="px-3 py-2 bg-green-500 rounded hover:bg-green-600"
              >
                Đăng ký
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
