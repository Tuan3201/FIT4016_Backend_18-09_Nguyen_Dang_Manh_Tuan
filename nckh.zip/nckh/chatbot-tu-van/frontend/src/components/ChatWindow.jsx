import React, { useState } from 'react';
import { useAuthStore } from '../store/store';
import { api } from '../api';
import { FiSend } from 'react-icons/fi';

export default function ChatWindow({ conversationId }) {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { token } = useAuthStore();

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    const userMessage = { role: 'user', content: message };
    setMessages([...messages, userMessage]);
    setMessage('');
    setIsLoading(true);

    try {
      const result = await api.sendMessage(
        { message, conversationId },
        token
      );

      if (result.success) {
        const botMessage = {
          role: 'bot',
          content: result.botResponse,
          intent: result.intent,
          confidence: result.confidence
        };
        setMessages(prev => [...prev, botMessage]);
      }
    } catch (error) {
      console.error('Lỗi gửi tin nhắn:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-lg shadow-lg">
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full text-gray-400">
            <p>Bắt đầu cuộc trò chuyện...</p>
          </div>
        )}
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                msg.role === 'user'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-200 text-gray-800'
              }`}
            >
              <p>{msg.content}</p>
              {msg.confidence && (
                <p className="text-xs opacity-70 mt-1">
                  Độ tin cậy: {(msg.confidence * 100).toFixed(0)}%
                </p>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-200 px-4 py-2 rounded-lg">
              <p className="text-gray-600">Đang xử lý...</p>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="border-t p-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Nhập câu hỏi của bạn..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            disabled={isLoading}
          />
          <button
            onClick={handleSendMessage}
            disabled={isLoading || !message.trim()}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 disabled:bg-gray-400 transition"
          >
            <FiSend size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
