const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export const api = {
  // Auth
  register: (data) => fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(r => r.json()),

  login: (data) => fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(r => r.json()),

  getCurrentUser: (token) => fetch(`${API_URL}/auth/me`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()),

  // Chatbot
  sendMessage: (data, token) => fetch(`${API_URL}/chatbot/send-message`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(data)
  }).then(r => r.json()),

  getConversations: (token) => fetch(`${API_URL}/chatbot/conversations`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()),

  getConversationDetail: (conversationId, token) => fetch(`${API_URL}/chatbot/conversations/${conversationId}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()),

  deleteConversation: (conversationId, token) => fetch(`${API_URL}/chatbot/conversations/${conversationId}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()),

  rateResponse: (conversationId, data, token) => fetch(`${API_URL}/chatbot/conversations/${conversationId}/rate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(data)
  }).then(r => r.json()),

  // FAQ
  getFAQs: (category = '') => fetch(`${API_URL}/faq${category ? `?category=${category}` : ''}`).then(r => r.json()),

  searchFAQs: (query) => fetch(`${API_URL}/faq/search?q=${encodeURIComponent(query)}`).then(r => r.json()),

  // User
  getUserProfile: (token) => fetch(`${API_URL}/users/profile`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()),

  updateUserProfile: (data, token) => fetch(`${API_URL}/users/profile`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(data)
  }).then(r => r.json()),

  // Admin
  getDashboardStats: (token) => fetch(`${API_URL}/admin/dashboard`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()),

  getUsers: (page = 1, limit = 20, token) => fetch(`${API_URL}/admin/users?page=${page}&limit=${limit}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()),

  getConversationAnalytics: (token) => fetch(`${API_URL}/admin/analytics/conversations`, {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json())
};
