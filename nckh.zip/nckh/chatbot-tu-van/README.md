# Chatbot Tư Vấn Học Tập

Ứng dụng Chatbot thông minh hỗ trợ sinh viên Khoa CNTT trong tư vấn học tập.

## Tính năng chính

### Cho sinh viên
- **Chat thông minh**: Trò chuyện với chatbot AI để nhận tư vấn học tập
- **Trả lời tự động**: Giải đáp các câu hỏi về:
  - Lịch học, lịch thi
  - Điểm số, kết quả học tập
  - Quy chế đào tạo, thủ tục hành chính
  - Gợi ý phương pháp tự học
  - Tài liệu tham khảo
- **Lịch sử cuộc hội thoại**: Lưu và xem lại các cuộc trò chuyện
- **Đánh giá**: Cho phản hồi về chất lượng câu trả lời

### Cho quản trị viên
- **Dashboard**: Xem thống kê tổng quát
- **Quản lý FAQ**: Thêm, sửa, xóa câu hỏi thường gặp
- **Quản lý người dùng**: Xem danh sách và quản lý tài khoản
- **Phân tích**: Xem phân tích cuộc hội thoại và phản hồi

## Cấu trúc dự án

```
chatbot-tu-van/
├── backend/              # Node.js + Express API
│   ├── models/          # Database schemas
│   ├── controllers/     # Business logic
│   ├── routes/          # API endpoints
│   ├── middleware/      # Authentication, authorization
│   ├── nlp/             # NLP engine
│   └── utils/           # Helper functions
├── frontend/            # React UI
│   ├── src/
│   │   ├── components/  # Reusable components
│   │   ├── pages/       # Page components
│   │   ├── store/       # Zustand state management
│   │   └── api.js       # API calls
│   └── public/          # Static files
└── README.md
```

## Yêu cầu hệ thống

- Node.js >= 14
- MongoDB >= 4.0
- npm hoặc yarn

## Cài đặt

### Backend

```bash
cd backend
npm install
```

Tạo file `.env` từ `.env.example`:

```bash
cp .env.example .env
```

Chỉnh sửa `.env` với thông tin kết nối MongoDB của bạn:

```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/chatbot-tu-van
JWT_SECRET=your_secret_key_here
NODE_ENV=development
API_URL=http://localhost:5000
FRONTEND_URL=http://localhost:3000
```

Chạy backend:

```bash
npm run dev  # Development mode
npm start    # Production mode
```

### Frontend

```bash
cd frontend
npm install
```

Tạo file `.env`:

```bash
cp .env.example .env
```

Chạy frontend:

```bash
npm start
```

Mở trình duyệt và truy cập `http://localhost:3000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Đăng ký tài khoản
- `POST /api/auth/login` - Đăng nhập
- `GET /api/auth/me` - Lấy thông tin người dùng hiện tại

### Chatbot
- `POST /api/chatbot/send-message` - Gửi tin nhắn
- `GET /api/chatbot/conversations` - Lấy danh sách cuộc hội thoại
- `GET /api/chatbot/conversations/:id` - Chi tiết cuộc hội thoại
- `DELETE /api/chatbot/conversations/:id` - Xóa cuộc hội thoại
- `POST /api/chatbot/conversations/:id/rate` - Đánh giá cuộc hội thoại

### FAQ
- `GET /api/faq` - Lấy danh sách FAQ
- `GET /api/faq/search?q=query` - Tìm kiếm FAQ
- `POST /api/faq` - Tạo FAQ (admin)
- `PUT /api/faq/:id` - Cập nhật FAQ (admin)
- `DELETE /api/faq/:id` - Xóa FAQ (admin)

### Admin
- `GET /api/admin/dashboard` - Thống kê dashboard
- `GET /api/admin/users` - Danh sách người dùng
- `GET /api/admin/analytics/conversations` - Phân tích cuộc hội thoại

## Công nghệ sử dụng

### Backend
- Express.js - Web framework
- MongoDB - Database
- Mongoose - ODM
- JWT - Authentication
- bcryptjs - Password hashing
- natural - NLP library

### Frontend
- React - UI library
- React Router - Routing
- Zustand - State management
- Tailwind CSS - Styling
- Axios - HTTP client

## Bắt đầu sử dụng

### Đăng ký tài khoản
1. Truy cập `http://localhost:3000`
2. Click "Đăng ký"
3. Điền thông tin và submit
4. Bạn sẽ được tự động đăng nhập

### Gửi tin nhắn đầu tiên
1. Ở trang chủ, viết câu hỏi của bạn
2. Chatbot sẽ phân tích và trả lời tự động
3. Bạn có thể đánh giá câu trả lời

### Quản lý (cho Admin)
1. Đăng nhập bằng tài khoản admin
2. Click "Admin" ở góc trên phải
3. Xem thống kê, quản lý người dùng và FAQ

## Huấn luyện Chatbot

Chatbot sử dụng NLP engine đơn giản với các intent đã định sẵn. Để huấn luyện tốt hơn:

1. **Thêm FAQ**: Quản trị viên thêm các câu hỏi-câu trả lời vào database
2. **Cập nhật intent**: Chỉnh sửa file `nlp/nlpEngine.js` để thêm pattern mới
3. **Tối ưu keywords**: Thêm keywords phù hợp giúp phân loại intent chính xác hơn

## Mô tả Chabot

Chatbot có khả năng:
- Nhận diện intent của người dùng qua NLP
- Trả lời câu hỏi từ FAQ database
- Theo dõi lịch sử cuộc hội thoại
- Ghi lại phản hồi người dùng để cải thiện

## Cấu trúc Database

### Users
- Lưu thông tin sinh viên, giảng viên, quản trị viên
- Hỗ trợ xác thực JWT

### Conversations
- Lưu tất cả các cuộc hội thoại
- Lưu message, intent, confidence score
- Lưu phản hồi người dùng

### FAQ
- Câu hỏi, câu trả lời, category
- Keywords, tags, intent
- Lượt xem, số người thấy hữu ích

### Feedback
- Đánh giá cuộc hội thoại
- Ghi nhận góp ý người dùng

## Hướng phát triển

1. **Tích hợp NLP nâng cao**: Sử dụng BERT, GPT hoặc các mô hình khác
2. **Tích hợp Zalo/Telegram**: Cho phép chat qua các nền tảng khác
3. **Mobile app**: Phát triển ứng dụng di động
4. **Personalization**: Cá nhân hóa gợi ý học tập
5. **LMS Integration**: Kết nối với Google Classroom, Moodle
6. **Multi-language**: Hỗ trợ nhiều ngôn ngữ

## Liên hệ & Hỗ trợ

Nếu có vấn đề, vui lòng liên hệ:
- Email: support@example.com
- Khoa CNTT, Đại học Đại Nam

## License

MIT License
