#!/usr/bin/env python3
"""
Chatbot Mock Server - Cho phép test ứng dụng mà không cần Node.js
Chạy: python mock_server.py
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
from urllib.parse import urlparse, parse_qs
import base64
from datetime import datetime, timedelta
import hmac
import hashlib

# Mock data
USERS = {
    "test@example.com": {
        "id": "1",
        "name": "Nguyễn Văn A",
        "email": "test@example.com",
        "password": "password123",
        "role": "student",
        "studentId": "SV001"
    },
    "admin@example.com": {
        "id": "2",
        "name": "Admin User",
        "email": "admin@example.com",
        "password": "admin123",
        "role": "admin",
        "studentId": None
    }
}

FAQS = [
    {
        "_id": "1",
        "question": "Lịch học ở đâu?",
        "answer": "Bạn có thể xem lịch học trên web sinh viên hoặc liên hệ Khoa CNTT.",
        "category": "schedule",
        "priority": 10
    },
    {
        "_id": "2",
        "question": "Khi nào công bố điểm?",
        "answer": "Giảng viên thường công bố điểm trong vòng 1-2 tuần sau kỳ thi.",
        "category": "score",
        "priority": 9
    },
    {
        "_id": "3",
        "question": "Cách xin nghỉ học?",
        "answer": "Nộp đơn xin nghỉ đến Phòng Quản lý sinh viên ít nhất 3 ngày trước.",
        "category": "procedure",
        "priority": 8
    }
]

CONVERSATIONS = []

class ChatbotRequestHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        """Handle GET requests"""
        path = urlparse(self.path).path
        
        if path == '/api/health':
            self.send_json(200, {"status": "OK", "timestamp": datetime.now().isoformat()})
        elif path == '/api/faq':
            self.send_json(200, {"success": True, "faqs": FAQS})
        elif path.startswith('/api/faq/search'):
            query = parse_qs(urlparse(self.path).query)
            q = query.get('q', [''])[0].lower()
            results = [f for f in FAQS if q in f['question'].lower() or q in f['answer'].lower()]
            self.send_json(200, {"success": True, "faqs": results})
        else:
            self.send_json(404, {"success": False, "message": "Endpoint không tìm thấy"})
    
    def do_POST(self):
        """Handle POST requests"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        path = urlparse(self.path).path
        
        try:
            data = json.loads(body) if body else {}
        except:
            data = {}
        
        if path == '/api/auth/register':
            self._handle_register(data)
        elif path == '/api/auth/login':
            self._handle_login(data)
        elif path == '/api/auth/me':
            self._handle_get_user(data)
        elif path == '/api/chatbot/send-message':
            self._handle_send_message(data)
        elif path == '/api/chatbot/conversations':
            self.send_json(200, {"success": True, "conversations": CONVERSATIONS})
        elif path == '/api/admin/dashboard':
            self._handle_dashboard(data)
        else:
            self.send_json(404, {"success": False, "message": "Endpoint không tìm thấy"})
    
    def _handle_register(self, data):
        email = data.get('email')
        if email in USERS:
            self.send_json(400, {"success": False, "message": "Email đã được đăng ký"})
        else:
            user = {
                "id": str(len(USERS) + 1),
                "name": data.get('name'),
                "email": email,
                "password": data.get('password'),
                "role": "student",
                "studentId": data.get('studentId')
            }
            USERS[email] = user
            token = self._generate_token(user)
            self.send_json(201, {
                "success": True,
                "message": "Đăng ký thành công",
                "user": {k: v for k, v in user.items() if k != 'password'},
                "token": token
            })
    
    def _handle_login(self, data):
        email = data.get('email')
        password = data.get('password')
        
        if email not in USERS or USERS[email]['password'] != password:
            self.send_json(401, {"success": False, "message": "Email hoặc mật khẩu không đúng"})
        else:
            user = USERS[email]
            token = self._generate_token(user)
            self.send_json(200, {
                "success": True,
                "message": "Đăng nhập thành công",
                "user": {k: v for k, v in user.items() if k != 'password'},
                "token": token
            })
    
    def _handle_get_user(self, data):
        auth_header = self.headers.get('Authorization', '')
        if not auth_header.startswith('Bearer '):
            self.send_json(401, {"success": False, "message": "Token không hợp lệ"})
            return
        
        # Mock user return
        user = {
            "id": "1",
            "name": "Nguyễn Văn A",
            "email": "test@example.com",
            "role": "student"
        }
        self.send_json(200, {"success": True, "user": user})
    
    def _handle_send_message(self, data):
        message = data.get('message', '')
        conversation_id = data.get('conversationId')
        
        # Simple intent detection
        intents = {
            'schedule': ['lịch học', 'lịch', 'buổi học', 'khi nào'],
            'exam': ['thi', 'lịch thi', 'kỳ thi', 'ngày thi'],
            'score': ['điểm', 'điểm số', 'bảng điểm'],
            'procedure': ['thủ tục', 'xin nghỉ', 'đăng ký'],
        }
        
        detected_intent = 'other'
        for intent, keywords in intents.items():
            if any(kw in message.lower() for kw in keywords):
                detected_intent = intent
                break
        
        # Generate response
        responses = {
            'schedule': "Bạn có thể xem lịch học trên web sinh viên hoặc liên hệ Khoa CNTT.",
            'exam': "Lịch thi thường được công bố 2-3 tuần trước kỳ thi. Vui lòng kiểm tra web.",
            'score': "Giảng viên thường công bố điểm trong vòng 1-2 tuần sau kỳ thi.",
            'procedure': "Vui lòng liên hệ với Phòng Quản lý sinh viên để được hướng dẫn chi tiết.",
            'other': "Tôi xin lỗi, tôi chưa hiểu rõ câu hỏi của bạn. Bạn có thể phát biểu lại được không?"
        }
        
        bot_response = responses.get(detected_intent, responses['other'])
        
        # Store conversation
        conv = {
            "id": conversation_id or str(len(CONVERSATIONS) + 1),
            "messages": [
                {"role": "user", "content": message},
                {"role": "bot", "content": bot_response}
            ],
            "intent": detected_intent
        }
        
        self.send_json(200, {
            "success": True,
            "conversationId": conv['id'],
            "botResponse": bot_response,
            "intent": detected_intent,
            "confidence": 0.85
        })
    
    def _handle_dashboard(self, data):
        self.send_json(200, {
            "success": True,
            "stats": {
                "totalUsers": len(USERS),
                "totalConversations": len(CONVERSATIONS),
                "totalFAQs": len(FAQS),
                "avgRating": 4.5
            }
        })
    
    def _generate_token(self, user):
        """Generate a simple JWT-like token"""
        payload = {
            "id": user['id'],
            "email": user['email'],
            "role": user['role']
        }
        import base64
        return base64.b64encode(json.dumps(payload).encode()).decode()
    
    def send_json(self, status, data):
        """Send JSON response"""
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())
    
    def do_OPTIONS(self):
        """Handle CORS preflight"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
    
    def log_message(self, format, *args):
        """Suppress default logging"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {format % args}")

if __name__ == '__main__':
    server_address = ('', 5000)
    httpd = HTTPServer(server_address, ChatbotRequestHandler)
    print("🚀 Mock Server đang chạy tại http://localhost:5000")
    print("📊 API Endpoints:")
    print("   GET  /api/health")
    print("   GET  /api/faq")
    print("   POST /api/auth/login")
    print("   POST /api/auth/register")
    print("   POST /api/chatbot/send-message")
    print("   GET  /api/admin/dashboard")
    print("\n🛑 Nhấn Ctrl+C để dừng server")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n✅ Server đã dừng")
        httpd.server_close()
