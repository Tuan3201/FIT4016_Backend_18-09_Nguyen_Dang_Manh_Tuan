# Dữ liệu mẫu - FAQ

Sau khi chạy ứng dụng, bạn có thể import các FAQ này vào database:

## Lịch học

**Q: Xem lịch học ở đâu?**
A: Bạn có thể xem lịch học trên web sinh viên của nhà trường hoặc liên hệ với Khoa CNTT để được cấp thông tin lịch học. Lịch thường được cập nhật vào đầu mỗi kỳ học.

**Q: Thay đổi lịch học được không?**
A: Lịch học được xác định bởi Khoa CNTT. Nếu có xung đột về lịch, bạn cần liên hệ với Phòng Đào tạo để xin chuyển lớp.

**Q: Lớp tôi học lúc mấy giờ?**
A: Giờ học thường là: Sáng (7h00 - 11h30), Chiều (13h00 - 16h30), Tối (17h00 - 20h30). Để biết chính xác, vui lòng xem lịch chi tiết trên web.

## Lịch thi

**Q: Lịch thi kỳ này là bao giờ?**
A: Lịch thi thường được công bố 2-3 tuần trước kỳ thi. Bạn có thể xem tại web sinh viên hoặc nhà trường sẽ gửi email thông báo.

**Q: Nếu trùng lịch thi thì sao?**
A: Nếu trùng lịch thi, bạn cần liên hệ với Phòng Đào tạo hoặc Khoa CNTT ngay để xin lịch thi riêng.

**Q: Phòng thi ở đâu?**
A: Địa điểm phòng thi sẽ được thông báo khi công bố lịch thi. Thường ở các phòng học trong các tòa nhà chính của nhà trường.

## Điểm số

**Q: Khi nào công bố điểm?**
A: Giảng viên thường công bố điểm trong vòng 1-2 tuần sau kỳ thi. Bạn có thể xem điểm trên web sinh viên.

**Q: Có cách phúc tra điểm được không?**
A: Có, bạn có thể xin phúc tra. Liên hệ với giảng viên dạy môn học trong 3 ngày sau khi công bố điểm.

**Q: Điểm F là gì?**
A: Điểm F (Fail - 0-3.99) là điểm không đạt. Bạn sẽ phải học lại môn này.

## Thủ tục hành chính

**Q: Cách xin nghỉ học?**
A: Bạn cần nộp đơn xin nghỉ (đính kèm giấy tờ chứng minh) đến Phòng Quản lý sinh viên. Cần làm ít nhất 3 ngày trước.

**Q: Đăng ký học phần như thế nào?**
A: Đăng ký học phần online trên web sinh viên theo lịch cho phép. Hạn chót thường là 2 tuần từ đầu kỳ.

**Q: Thôi học như thế nào?**
A: Liên hệ với Khoa CNTT để được tư vấn. Thôi học mid-term cần xin trước kỳ thi giữa kỳ.

## Phương pháp học

**Q: Nên học môn Lập trình như thế nào?**
A: Hãy làm bài tập thực hành nhiều, tự viết code. Đọc tài liệu tham khảo, xem video hướng dẫn, và hỏi giảng viên khi không hiểu.

**Q: Nên học môn toán như thế nào?**
A: Hiểu lý thuyết, làm bài tập từ cơ bản đến nâng cao. Ôn tập thường xuyên thay vì học cấp tốc.

**Q: Có tài liệu tham khảo nào không?**
A: Khoa CNTT có thư viện tài liệu. Các giảng viên cũng sẽ cấp tài liệu học tập. Ngoài ra có nhiều tài liệu miễn phí trên mạng.

**Q: Nên học nhóm hay học một mình?**
A: Cả hai đều tốt. Học nhóm giúp hiểu rõ hơn qua thảo luận. Học một mình giúp tập trung hơn. Kết hợp cả hai là tốt nhất.

## Quy chế

**Q: GPA tối thiểu để giữ học bổng là bao nhiêu?**
A: Thường là GPA >= 3.0. Chi tiết xem quy chế học bổng của nhà trường.

**Q: Điều kiện lên lớp là gì?**
A: Bạn cần vượt qua tất cả các môn học. Không được điểm F ở bất kỳ môn nào.

**Q: Còn bao lâu nữa tôi mới ra trường?**
A: Nếu đầu vào là high school (12 năm), chương trình là 4 năm. Nếu đầu vào là college (14 năm), chương trình là 2 năm.
