# 🤖 HƯỚNG DẪN KÍCH HOẠT GEMINI AI TRONG CHATBOT

## 📋 Bước 1: Cài Đặt Thư Viện Google AI

Chạy lệnh sau trong Terminal/PowerShell:

```bash
pip install google-generativeai
```

## 🔑 Bước 2: Lấy API Key Từ Google

1. Truy cập: **https://aistudio.google.com/app/apikey**
2. Click "Create API Key" → "Create API key in new project"
3. Copy API key (dạng: `AIza...`)

**⚠️ QUAN TRỌNG:** Giữ bí mật API key - không chia sẻ công khai!

## 🚀 Bước 3: Khởi Động AI Server

### Windows (PowerShell):
```powershell
$env:GEMINI_API_KEY='your-api-key-here'
python ai_server.py
```

### Windows (Command Prompt):
```cmd
set GEMINI_API_KEY=your-api-key-here
python ai_server.py
```

### Linux/Mac:
```bash
export GEMINI_API_KEY='your-api-key-here'
python ai_server.py
```

**Ví dụ đầy đủ:**
```powershell
$env:GEMINI_API_KEY='AIzaSyDxRt7nKfPqrQpQpRsQqQqQqQqQqQqQqQq'
python ai_server.py
```

## 🌐 Bước 4: Chạy Chatbot

1. Mở Terminal mới (giữ nguyên Terminal chạy ai_server.py)
2. Chạy frontend server (nếu chưa chạy):
```powershell
cd d:\baocaotiendo\nckh\chatbot-tu-van
python frontend_server.py
```

3. Truy cập: **http://localhost:3000/ai-enabled.html**

## ✅ Kiểm Tra AI Hoạt Động

### Trên Chatbot:
1. Đăng nhập/Đăng ký
2. Click toggle "📚 FAQ" để chuyển sang "🤖 AI"
3. Nếu thành công → Sẽ hiển thị "🤖 AI Bật" (xanh)
4. Hỏi bất kỳ câu hỏi gì

### Các Dấu Hiệu:
- ✅ "🤖 Gemini AI" - AI trả lời
- ✅ "📚 FAQ Database" - FAQ trả lời (fallback)
- ❌ "AI Server chưa được khởi động" - Cần chạy ai_server.py

## 📊 So Sánh FAQ vs AI

| Tính Năng | FAQ | AI (Gemini) |
|-----------|-----|-----------|
| Kho dữ liệu | 80+ câu cố định | Vô hạn kiến thức |
| Câu hỏi lạ | ❌ Không có | ✅ Có thể trả lời |
| Giải thích chi tiết | ✅ Có | ✅ Rất chi tiết |
| Tốc độ | ⚡ Cực nhanh | 🔄 Cần 1-2 giây |
| Thành phố Internet | ✅ Offline | ❌ Cần Internet |

## 🛠️ Troubleshooting

### Lỗi 1: "ModuleNotFoundError: No module named 'google'"
```bash
pip install google-generativeai
```

### Lỗi 2: "AI Server không phản hồi"
- Kiểm tra ai_server.py đang chạy: `python ai_server.py`
- Kiểm tra cổng 5001 không bị chiếm
- Restart Terminal

### Lỗi 3: "Invalid API key"
- Kiểm tra API key chính xác
- Chắc chắn đặt biến environment trước khi chạy
- Lấy API key mới từ: https://aistudio.google.com/app/apikey

### Lỗi 4: "CORS error"
- Đảm bảo frontend (port 3000) và AI server (port 5001) đều chạy
- Không block port 5001 bằng firewall

## 💾 Cấu Hình Lưu Trữ Cửa Sổ PowerShell

Tạo file `run-ai-server.ps1`:
```powershell
$env:GEMINI_API_KEY='AIzaSyDxRt7nKfPqrQpQpRsQqQqQqQqQqQqQqQq'
python ai_server.py
```

Sau đó chạy:
```powershell
.\run-ai-server.ps1
```

## 🔐 Bảo Mật API Key

### ❌ KHÔNG làm:
- Commit API key vào Git
- Share công khai trên mạng
- Để API key trong file config

### ✅ LÀM:
- Dùng environment variables
- Dùng `.env` file (local chỉ)
- Rotate key định kỳ
- Kiểm soát quota & billing

## 📞 Liên Hệ Hỗ Trợ

- Google AI Studio: https://aistudio.google.com/
- Gemini API Docs: https://ai.google.dev/
- Python SDK: https://github.com/google/generative-ai-python

---

**🎉 Hoàn tất! Chatbot AI của bạn đã sẵn sàng hoạt động!**
