#!/usr/bin/env powershell
# Script khởi động AI Server với Gemini API

Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  KHỞI ĐỘNG GEMINI AI SERVER" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Kiểm tra API Key
$apiKey = $env:GEMINI_API_KEY
if ([string]::IsNullOrEmpty($apiKey)) {
    Write-Host "❌ GEMINI_API_KEY chưa được cấu hình!`n" -ForegroundColor Red
    
    Write-Host "📋 HƯỚNG DẪN LẤY API KEY:" -ForegroundColor Yellow
    Write-Host "  1. Mở: https://aistudio.google.com/app/apikey" -ForegroundColor White
    Write-Host "  2. Click 'Create API Key' → 'Create API key in new project'" -ForegroundColor White
    Write-Host "  3. Copy API key (dạng: AIza...)`n" -ForegroundColor White
    
    Write-Host "⚙️  CÁCH CẤU HÌNH:" -ForegroundColor Yellow
    Write-Host "  Cách 1 - Chạy ngay (tạm thời):" -ForegroundColor White
    Write-Host '    $env:GEMINI_API_KEY="AIza..."' -ForegroundColor Cyan
    Write-Host "    .\run-ai-server.ps1`n" -ForegroundColor Cyan
    
    Write-Host "  Cách 2 - Lưu vĩnh viễn:" -ForegroundColor White
    Write-Host "    [Environment]::SetEnvironmentVariable('GEMINI_API_KEY','AIza...','User')" -ForegroundColor Cyan
    Write-Host "    Khởi động lại PowerShell, rồi chạy: .\run-ai-server.ps1`n" -ForegroundColor Cyan
    
    Write-Host "📝 NHẬP API KEY BÂY GIỜ (hoặc Enter để bỏ qua):" -ForegroundColor Yellow
    $manualKey = Read-Host
    
    if ($manualKey) {
        $env:GEMINI_API_KEY = $manualKey
        Write-Host "✅ API Key đã được cấu hình tạm thời`n" -ForegroundColor Green
    } else {
        Write-Host "`n⚠️  Chạy mà không API Key - sẽ dùng FAQ mode`n" -ForegroundColor Yellow
    }
}

if ($env:GEMINI_API_KEY) {
    Write-Host "✅ API Key: $($env:GEMINI_API_KEY.Substring(0, 10))..." -ForegroundColor Green
}

Write-Host "`n🚀 Khởi động AI Server (port 5001)..." -ForegroundColor Green
Write-Host "💾 Kiểm tra thư viện google-generativeai..." -ForegroundColor Cyan

# Cài đặt thư viện nếu chưa có
python -c "import google.generativeai" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "📦 Cài đặt google-generativeai..." -ForegroundColor Yellow
    pip install -q google-generativeai
    Write-Host "✅ Cài đặt xong`n" -ForegroundColor Green
}

Write-Host "`n📡 AI Server đang chạy..." -ForegroundColor Green
Write-Host "   🌐 Chatbot: http://localhost:3000/ai-enabled.html" -ForegroundColor Cyan
Write-Host "   🤖 AI API: http://localhost:5001" -ForegroundColor Cyan
Write-Host "`n⚠️  Nhấn Ctrl+C để dừng`n" -ForegroundColor Yellow

python ai_server.py
